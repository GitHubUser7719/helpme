# BazaarNotifier

Mod and Discord Bot for Hypixel Skyblock that helps with tracking bazaar sell offer and buy order movements



All bug reports should be in [issues](https://github.com/symt/BazaarNotifier/issues) or in the discord server.

## Extras

Join the discord server: https://discord.com/invite/wjpJSVSwvD


<hr/>

<sub>[License](https://github.com/symt/BazaarNotifier/blob/master/license.txt) | [Site](https://meyi.dev)</sub>
